package com.syntel.corejava.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class TestAccount {

	Map<Integer, Account> map;
	
	
	

	public TestAccount() throws IOException, ClassNotFoundException {

		File f = new File("account.ser");

		if (f.exists()) {

			FileInputStream fis = new FileInputStream(f);
			ObjectInputStream ois = new ObjectInputStream(fis);
			map = (Map<Integer, Account>) ois.readObject();
			System.out.println("Existing Map createdd " + map.size());
			ois.close();

		} else {
			map = new HashMap<>();
			System.out.println("New Map Created.. " + map.size());
		}

	}

	public void addAccount(Account account) {
		
		map.put(account.getAccno(), account);
		
		System.out.println("Account added...");
	}

	public void getAccount(int accno) {

		if (map.containsKey(accno))
			System.out.println("Account :" + map.get(accno));
		else
			System.out.println("Account " + accno + " doesn't exist...");

	}

	public void removeAccount(int accno) {

		if (map.containsKey(accno)) {
			map.remove(accno);
			System.out.println("Account :" + accno + "  removed");
		} else
			System.out.println("Account " + accno + " doesn't exist...");

	}

	public void showAllAccounts() {
		System.out.println("Account Details");
		System.out.println("==================");
		for (Account account : map.values())
			System.out.println(account);
	}

	public void withdraw(int accno, double amount) throws InsufficientBalanceException {

		if (map.containsKey(accno)) {
			map.get(accno).withdraw(amount);

		} else
			System.out.println("Account " + accno + " doesn't exist...");

	}

	public void deposit(int accno, double amount) throws AmountOverflowException {

		if (map.containsKey(accno)) {
			map.get(accno).deposit(amount);

		} else
			System.out.println("Account " + accno + " doesn't exist...");

	}

	public void sortAccountsByAccno() {

		TreeMap<Integer, Account> tm = new TreeMap<>(map);

		System.out.println("Accounts Sorted By Accno");
		System.out.println("==================");
		for (Account account : tm.values())
			System.out.println(account);

	}

	public void save() throws IOException {

		FileOutputStream fos = new FileOutputStream("account.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		oos.writeObject(map);

		oos.close();
		System.out.println(map.size() + " accounts stored in a file...");

	}

	public static void main(String[] args) {

		int choice = 0;
		Scanner sc = null;
		TestAccount ta = null;

		try {
			ta = new TestAccount();
			sc = new Scanner(System.in);

			while (choice < 8) {
				System.out.println("Banking Operations");
				System.out.println("=======================");
				System.out.println("1.Add Account");
				System.out.println("2.Remove Account");
				System.out.println("3.Show Account");
				System.out.println("4.Show All Account");
				System.out.println("5.Withdraw Amount");
				System.out.println("6.Deposit Amount");
				System.out.println("7.Sort Accounts By Accno");
				System.out.println("8.Exit");
				System.out.println("Enter choice");
                choice=sc.nextInt(); 
				switch (choice) {
				case 1:
					System.out.println("Enter accno,name,balance");
					
					Account account = new Account(sc.nextInt(), sc.next(),
							sc.nextDouble());

					ta.addAccount(account);

					break;

				case 2:
					System.out.println("Enter accno");

					ta.removeAccount(sc.nextInt());

					break;
				case 3:
					System.out.println("Enter accno");

					ta.getAccount(sc.nextInt());

					break;
				case 4:
					ta.showAllAccounts();

					break;
				case 6:
					System.out.println("Enter accno & amount");
					ta.deposit(sc.nextInt(), sc.nextDouble());

					break;
				case 5:
					System.out.println("Enter accno & amount");
					ta.withdraw(sc.nextInt(), sc.nextDouble());

					break;
				case 7:
					ta.sortAccountsByAccno();
					
						break;		
				default:
					    ta.save();
					return;
				
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
