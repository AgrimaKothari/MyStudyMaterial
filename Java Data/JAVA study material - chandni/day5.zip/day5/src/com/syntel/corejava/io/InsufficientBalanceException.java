package com.syntel.corejava.io;

public class InsufficientBalanceException extends Exception{

	public InsufficientBalanceException(String message) {
		super(message);
	}
	
	

}
