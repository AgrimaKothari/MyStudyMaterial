package com.syntel.corejava.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;

public class CopyFileDemo {
	
	
	void copy(String source,String destination){
		
		try(
		   FileInputStream fis=new FileInputStream(source);
		   FileOutputStream fos=new FileOutputStream(destination);
			 
			){
			
			File f=new File(source);
			
			System.out.println("Copying file ....");
			int size=(int)f.length();
			byte []buf=new byte[size];
			
			System.out.println("Before reading Buf :"+Arrays.toString(buf));
			
			fis.read(buf);
			
			System.out.println("After reading Buf :"+Arrays.toString(buf));
			
			fos.write(buf);
			Thread.sleep(4000);
			
			
			System.out.println("File Copying over.....");
			
			
		}catch (Exception e) {
	
		e.printStackTrace();
		
		}
		
		
		
		
	}
	
	
public static void main(String[] args) {
	
	new CopyFileDemo().copy("syntel.txt", "output.txt");
	
}
}
