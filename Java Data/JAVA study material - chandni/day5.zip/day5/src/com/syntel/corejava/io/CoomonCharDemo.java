package com.syntel.corejava.io;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class CoomonCharDemo {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter sentence1 :");
	String word1=sc.nextLine();
	
	System.out.println("Enter sentence2 :");
	String word2=sc.nextLine();
	
	ArrayList<Character> arl1=new ArrayList<>();
	
	for(int i=0;i<word1.length();i++)
		arl1.add(word1.charAt(i));
	
	
	
	
	ArrayList<Character> arl2=new ArrayList<>();
	
	for(int i=0;i<word2.length();i++)
		arl2.add(word2.charAt(i));
	
	System.out.println("ARL1   :"+arl1);
	System.out.println("ARL2   :"+arl2);
	
	arl1.retainAll(arl2);
	
	System.out.println("Common Characters :"+arl1);
	
	
	
	
	
	
	
}
}
