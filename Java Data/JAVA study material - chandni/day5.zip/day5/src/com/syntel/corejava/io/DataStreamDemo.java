package com.syntel.corejava.io;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class DataStreamDemo {

	void writeData() {

		try (
		// To read data from kb
		InputStreamReader isr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(isr);

		// to write data in file
		FileOutputStream fos = new FileOutputStream("student.txt");

	   //to write primitive datatypes			
				
	   DataOutputStream dos=new DataOutputStream(fos);			
				
				
		) {
			
			
			System.out.println("Enter id ");
			int id=Integer.parseInt(br.readLine());
			System.out.println("Enter name ");
			String name=br.readLine();
			System.out.println("Enter salary ");
			double salary=Double.parseDouble(br.readLine());
			System.out.println("Enter gender ");
			char gender=(char)br.read(); 
			
			dos.writeInt(id);
			dos.writeUTF(name);
			dos.writeDouble(salary);
			dos.writeChar(gender);
	
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void readData() {

		try (

		// to read data from file
		FileInputStream fis = new FileInputStream("student.txt");
        DataInputStream dis=new DataInputStream(fis);
				
		) {

			System.out.println("File Contents...");
			
			System .out.println("Id    :"+dis.readInt());
			System.out.println("Name   :"+dis.readUTF());
			System.out.println("Salary :"+dis.readDouble());
			System.out.println("Gender :"+dis.readChar());
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

DataStreamDemo dsd=new DataStreamDemo();

dsd.writeData();
dsd.readData();

	}

}
