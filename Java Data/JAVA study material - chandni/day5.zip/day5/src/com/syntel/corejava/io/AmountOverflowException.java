package com.syntel.corejava.io;

public class AmountOverflowException extends Exception{

	public AmountOverflowException(String message) {
		super(message);
	}

	
	
}
