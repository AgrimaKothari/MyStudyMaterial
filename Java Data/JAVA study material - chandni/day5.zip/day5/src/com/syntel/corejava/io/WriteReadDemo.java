package com.syntel.corejava.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class WriteReadDemo {

	void writeData() {

		try (
		  FileWriter fw=new FileWriter("data.txt");
		  BufferedWriter bw=new BufferedWriter(fw);		
		  ) {
			
		String str="This is Sysntel. I am employee here";
		
		for(int i=0;i<str.length();i++)	
		bw.write(str.charAt(i));
		
		System.out.println("Data Written in a file....");	
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void readData() {

		try (

		FileReader fr=new FileReader("data.txt");
		BufferedReader br=new BufferedReader(fr);		
				
				
		) {
System.out.println("File Contents \n==================");
			int ch;
			while((ch=br.read())!=-1)
			System.out.print((char)ch);	
					
			System.out.println("File Reading over..");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		WriteReadDemo wr=new WriteReadDemo();
		wr.writeData();
		wr.readData();
		
		
	}

}
