package com.syntel.corejava.io;

import java.util.HashMap;
import java.util.Scanner;

public class WordCountDemo {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter sentence :");
	String sentence=sc.nextLine();
	
	String str[]=sentence.split("\\W");
	System.out.println("Number of words :"+str.length);

	HashMap<String, Integer> map=new HashMap<>();
	
	for(String s:str){
		if(map.containsKey(s))
			map.put(s, map.get(s)+1);
		else
		map.put(s,1);	
	}
	
	System.out.println("Map :"+map);
	
	
	
	
	
	
	
	
}
}
