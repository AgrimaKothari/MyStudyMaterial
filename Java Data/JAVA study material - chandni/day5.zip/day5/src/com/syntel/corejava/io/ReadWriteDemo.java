package com.syntel.corejava.io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadWriteDemo {

	void readFromKeyboardAndWriteIntoFile() {

		try (
		// To read data from kb
		InputStreamReader isr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(isr);

		// to write data in file
		FileOutputStream fos = new FileOutputStream("syntel.txt");

		) {
			System.out
					.println("Enter data & use @ symbol to save the contents in file");
			char ch;

			while ((ch = (char) br.read()) != '@') {
				fos.write(ch);
			}

			System.out.println("Data Saved in the file....");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void readFromFileAndDisplayOnMonitor() {

		try (

		// to read data from file
		FileInputStream fis = new FileInputStream("syntel.txt");

		) {

			System.out.println("File Contents...");
			int ch;
			while ((ch = fis.read()) != -1)
				System.out.print((char) ch);

			System.out.println("Reading Contents From File Over......");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		ReadWriteDemo rwd = new ReadWriteDemo();

		rwd.readFromKeyboardAndWriteIntoFile();
		
		
		
		rwd.readFromFileAndDisplayOnMonitor();

	}

}
