package com.syntel.corejava.threading;

class Print extends Thread{
	
	public void run() {
	
	for(int i=1;i<=10;i++)
	{
	System.out.println(Thread.currentThread().getName()+" prints "+i);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	}
	}
	
}


public class ThreadDemo {
public static void main(String[] args) throws InterruptedException {
	
	Print p1=new Print(); //New State
	Print p2=new Print(); //New State
	
	p1.setName("Pradeep");
	p2.setName("Prakash");
	
	//p1.run();
	p1.start();
	p1.start();
	//p1.join(5000);
	//p2.start();
	
}
}
