package com.syntel.corejava.threading;

public class CurrentThreadDemo {
	public static void main(String[] args) {
		
	//get currently running thread
		
	Thread t=Thread.currentThread();
	
	t.setName("MyThread");
	//t.setPriority(Thread.MIN_PRIORITY);
	t.setPriority(7);
	
	System.out.println(" t ="+t);
	System.out.println("Thread Name  :"+t.getName());
	System.out.println("Thread Priority :"+t.getPriority());
	System.out.println("Thread Group :"+t.getThreadGroup());
			
		
	}
	
}
