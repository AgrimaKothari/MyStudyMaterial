package com.syntel.corejava.threading;

public class DaemonThread {
public static void main(String[] args) {
	System.out.println("Main Thread start...");
	
	Print p=new Print();
	p.setDaemon(true);
	
	p.start();
	System.out.println("Main Thread End...");
}
}
