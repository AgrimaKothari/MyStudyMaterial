package com.syntel.corejava.collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.Vector;

public class ListDemo {
public static void main(String[] args) {
	
	List<String>  list=null;
	
	// list=new ArrayList<String>();
	//list=new LinkedList<String>();
	//list=new Vector<String>();
	list=new Stack<String>();
	
	System.out.println("Size     :"+list.size());
	System.out.println("Is Empty :"+list.isEmpty());
	
	
	list.add("APPLE");
	list.add("BANANA");
	list.add("MANGO");
	list.add("GRAPES");
	list.add(2,"SAPOTA");
	
	System.out.println("After insertion  ");
	System.out.println("Size     :"+list.size());
	System.out.println("Is Empty :"+list.isEmpty());
	System.out.println("Contents :"+list);
	
	
	
	
	list.remove(2);
	list.remove("MANGO");
	list.set(2,"WATERMILON");
	list.add("PINEAPLE");
	list.add("APPLE");
	
	
	System.out.println("After updation :");
	System.out.println("Contents :"+list);
	
	
	System.out.println("indexof apple  :"+list.indexOf("APPLE"));
	System.out.println("alstindexof apple  :"+list.lastIndexOf("APPLE"));
	
	
	System.out.println("Is SAPOTA AVAILABLE :"+list.contains("SAPOTA"));
	
	
	ArrayList<String> arl=new ArrayList<>();
	arl.add("APPLE");
	arl.add("PINEAPLE");
	
		
	//System.out.println("retainAll :"+list.retainAll(arl));
//	System.out.println("After retianAll Conents :"+list);
	
	System.out.println("removeAll :"+list.removeAll(arl));
	System.out.println("After removeAll Conents :"+list);
	
	list.clear();
	System.out.println("Conents :"+list);
	
	
	
	
	
	
	
}
}
