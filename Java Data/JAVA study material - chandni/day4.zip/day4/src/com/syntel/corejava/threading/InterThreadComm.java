package com.syntel.corejava.threading;

import com.sun.swing.internal.plaf.synth.resources.synth;


class Storage{
int n;
boolean flag;


synchronized public void setN(int n) {
	
	if(flag)
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	this.n = n;
    flag=true; 
    notifyAll();
	System.out.println("Value Set :"+n);


}


synchronized public int getN() {
	System.out.println("Value Got :"+n);
	
	if(!flag)
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	flag=false;
	notifyAll();
	return n;
}
	
	
}



class Counter extends Thread
{
Storage s;



public Counter(Storage s) {
this.s=s;
start();
}

public void run() {
int n=0;
while(true)
	s.setN(n++);

}
}

class Printer extends Thread
{
Storage s;

public Printer(Storage s) {
this.s=s;
start();
}

public void run() {

while(true)
	s.getN();
}
}


public class InterThreadComm {
public static void main(String[] args) {
	
Storage s=new Storage();

new Counter(s);
new Printer(s);

	
	
}
}
