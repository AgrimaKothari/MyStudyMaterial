package com.syntel.corejava.collection;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class MapDemo {

Map<String, String> map;

public MapDemo() {
	map=new HashMap<>();    //Not Ordered
//	map=new LinkedHashMap<>();  //Insertion Ordered
//	map=new Hashtable<>();  //Thread safe and not ordered
//	map=new TreeMap<>();   //Sorted on key basis
}

	
public void addEntry(String name,String mobile)
{
	map.put(name, mobile);
	System.out.println("Entry added in phone book");
}

public void removeEntry(String name)
{
	if(map.containsKey(name))
	{
	map.remove(name);
	System.out.println("Entry removed..");
	}
	else
	System.out.println("Name doesn't exist");
}

	
public void getEntry(String name)
{
	if(map.containsKey(name))
	{
	System.out.println("Mobile :"+map.get(name));
	}
	else
	System.out.println("Name doesn't exist");
}

	
public void updateEntry(String name,String mobile)
{
	if(map.containsKey(name))
	{
	map.put(name, mobile);	
	System.out.println("Entry updated ");
	}
	else
	System.out.println("Name doesn't exist");
}
	
public void showAllEntry()
{
	System.out.println("=====================================");
	System.out.println("Name                Mobile");
	System.out.println("====================================");
    for(Entry<String, String> e :map.entrySet()){
    System.out.println(e.getKey()+"==========="+e.getValue());
    }
 }
public void removeAllEntry()
{
map.clear();
System.out.println("All entries removed....");
}


	
	
	
public static void main(String[] args) {
	
	int choice=0;
	Scanner sc=new Scanner(System.in);
	MapDemo md=new MapDemo();
	
	
	while(choice<8)
	{
		System.out.println("1.Add Entry");
		System.out.println("2.Remove Entry");
		System.out.println("3.Show Entry");
		System.out.println("4.Show All Entry");
		System.out.println("5.Update Entry");
		System.out.println("6.Remove All Entries");
		System.out.println("7.Exit");
		System.out.println("Enter the choice :");
		choice=sc.nextInt();
		
	switch (choice) {
	case 1: 
	    System.out.println("Enter name & mobile");
	    md.addEntry(sc.next(), sc.next()); 
	
	break;
	case 2: 
	    System.out.println("Enter name ");
	    md.removeEntry(sc.next()); 
	
	break;
	case 3: 
	    System.out.println("Enter name ");
	    md.getEntry(sc.next()); 
	
	break;
	case 4: 
             md.showAllEntry();	
	break;
	case 5: 
	    System.out.println("Enter name & mobile");
	    md.addEntry(sc.next(), sc.next()); 
	
	break;
	case 6: 
	    md.removeAllEntry();
	break;

	default: return;
		}	
		
		
		
		
		
	}
	
	
	
	
}
}
