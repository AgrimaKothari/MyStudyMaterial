package com.syntel.corejava.threading;


class Reservation implements Runnable{
	
private int avaibale=1;
int wanted;


public Reservation(int n) {
this.wanted=n;
}

	
 public void run() {
System.out.println(" Booking ticket for "+Thread.currentThread().getName());	
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
synchronized (this) {
System.out.println("In sync block "+Thread.currentThread().getName());	
	
if(avaibale>=wanted)
{
avaibale=avaibale-wanted;
System.out.println(wanted+" seats booked for "+Thread.currentThread().getName());	
}
else
	System.out.println("No seats avaiable for "+Thread.currentThread().getName());	
	
}	
}//run 
}//Reservation




public class Sync {
public static void main(String[] args) {
	
	Reservation r=new Reservation(1);
	
	
	
	
	Thread t1=new Thread(r, "RAM");
	Thread t2=new Thread(r, "RAHIM");
	Thread t3=new Thread(r, "DAVID");
	
	//start the threads
	t1.start();
	t2.start();
	t3.start();
	
	
}
}
