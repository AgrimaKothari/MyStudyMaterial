package com.syntel.corejava.collection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
public static void main(String[] args) {
	
	Set<String> set=null;
	
	
	//set=new HashSet<>();  //not ordered
	//set=new LinkedHashSet<>(); //insertion order
	set=new TreeSet<>(); //sorted in assending 
	
	/*
	 *  a and b
	 *  a and b should be of same type
	 *  a.hashCode ==b.hashCode should return true
	 *  a.equals(b) should return true
	 *  */
	
	
	System.out.println("Added :"+set.add("PRADEEP"));
	System.out.println("Added :"+set.add("SACHIN"));
	System.out.println("Added :"+set.add("RAMESH"));
	System.out.println("Added :"+set.add("MAHESH"));
	System.out.println("Added :"+set.add("SUNIL"));
	System.out.println("Added :"+set.add("MAYUR"));
	System.out.println("Added :"+set.add("PRADEEP"));
	
	
	System.out.println("Size :"+set.size());
	System.out.println("Contents :"+set);
	
	
	
	
	
	
}
}
