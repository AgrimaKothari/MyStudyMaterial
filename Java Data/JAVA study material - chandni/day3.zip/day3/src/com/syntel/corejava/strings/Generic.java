package com.syntel.corejava.strings;

public class Generic<T> {
T ref;

public Generic() {
}

public Generic(T ref) {
	super();
	this.ref = ref;
}


	public void setRef(T ref) {
		this.ref = ref;
	}
	
	public T getRef() {
		return ref;
	}
	
	public void show(){
		System.out.println("ref class :"+ref.getClass().getName());
		System.out.println("crnt class :"+this.getClass().getName());
		
	}
	
	public static void main(String[] args) {
		Generic<Integer> g1=new Generic<>(); //Java 7 feature
		Generic<String> g2=new Generic<>();
		
				
		
		
		g1.setRef(456);
		g2.setRef("pradeep");
		
		float v1=g1.getRef();
		String v2=g2.getRef();
		
		g1.show();
		g2.show();
		
		System.out.println("v1 :"+v1);
        System.out.println("v2 :"+v2);

		
	//	g1=g2;
		
		
		
		
	}
	
}
