package com.syntel.corejava.strings;

public class NonGeneric {
Object ref;

public NonGeneric() {
}

public NonGeneric(Object ref) {
	super();
	this.ref = ref;
}


	public void setRef(Object ref) {
		this.ref = ref;
	}
	
	public Object getRef() {
		return ref;
	}
	
	public void show(){
		System.out.println("ref class :"+ref.getClass().getName());
		System.out.println("crnt class :"+this.getClass().getName());
		
	}
	
	public static void main(String[] args) {
		
		NonGeneric n1=new NonGeneric("pradeep"); //String =>Object
		NonGeneric n2=new NonGeneric(12345); //int->Integer->Object
		
		n1.show();
		n2.show();
		
		
		String s1=(String)n2.getRef();
		
		Integer v1=(Integer)n2.getRef();
		
				System.out.println("s1 :"+s1);
		        System.out.println("v1:"+v1);
		
		
		n1=n2;
		
		
	}
	
}
