package com.syntel.corejava.java5features;

public class VarArgsDemo {

/*static void sum(int a,int b){
	System.out.println("a+b :"+(a+b));
}
*/	
static void sum(int ...arr){
	
	int n=arr.length;
	
	int sum=0;
	
	for(int a:arr)
		sum=sum+a;
	
	System.out.println("sum of "+n+" numbers :"+sum);
	
	
}
	
	
public static void main(String[] args) {
	sum();
	sum(10);
	sum(10,20);
	sum(10,20,30);
}
}
