package com.syntel.corejava.exceptions;

public class Ex2 {
	
	private Ex2() {
	}
	
	
	
public static void main(String[] args) {
	
	
try{	
int n=args.length;	
System.out.println("Number of Arguments :"+n);	
System.out.println("Open the files....");
int a=100/n;//Ex
System.out.println("a = "+a);
int arr[]={10,20,30};
arr[5]=45; //EX
}
catch(ArithmeticException e){
e.printStackTrace();
System.out.println("Please pass the arguments to main method..");
}
catch(ArrayIndexOutOfBoundsException e){
e.printStackTrace();
System.out.println("Index Out of Range");
}

finally{
System.out.println("Close the files..");
}
	
}
}
