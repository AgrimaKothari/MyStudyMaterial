package com.syntel.corejava.java5features;

public class ForEachDemo {
public static void main(String[] args) {
	
  for(int i=0;i<args.length;i++)
	System.out.println(args[i]);

  
  
  
System.out.println("===================");
for(String s:args)
System.out.println(s);
	
	
}
}
