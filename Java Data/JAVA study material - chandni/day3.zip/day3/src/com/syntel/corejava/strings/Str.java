package com.syntel.corejava.strings;

public class Str {
public static void main(String[] args) {
	
	//create four strings

	String s1="This is a java . ";

	String s2=new String("I like it");

	char arr[]={'S','Y','N','T','E','L'};

	String s3=new String(arr);

	byte arr1[]={65,66,67,68,69,70};
	
	String s4=new String (arr1);
	
	//display 4 strings

	System.out.println("s1="+s1);
	System.out.println("s2="+s2);
	System.out.println("s3="+s3);
	System.out.println("s4="+s4);
	

	//find no. of elements in s1

	System.out.println("Length of s1="+s1.length());

	//join s1 with s2

	System.out.println("s1 joined with s2 ="+s1.concat(s2));

	//join 3 strings using +

	System.out.println(s1+" at "+s3);

	//Test whether s1 starts with This

	boolean x=s1.startsWith("This");

	if(x==true)
	System.out.println("s1 starts with This");
	else
	System.out.println("s1 doesnot start ith This");

	//Extract substrings from s2 and s3

	String p=s2.substring(0,7);

	String q=s3.substring(0);

	System.out.println(p+q);

	//Convert s1 to upper case

	System.out.println("Upper s1="+s1.toUpperCase());

	System.out.println("Lower s1="+s1.toLowerCase());

	System.out.println("s1.indexOf(a) :"+s1.indexOf('a'));
	System.out.println("s1.lastIndexOf(a) :"+s1.lastIndexOf('a'));
	System.out.println("s1.charAt(8) :"+s1.charAt(8));
	
	String s=" AMAR ";

	System.out.println("Before trim :"+s.length());

	String ss=s.trim();
	System.out.println("After trim :"+ss.length());
	
	
	String name=new String("Pradeep");
	
	System.out.println("Before name  :"+name);
	String name1=name.toUpperCase();
	System.out.println("After name  :"+name+"   "+name1);
		
	
	String s5=new String("Hi");
	String s6=new String("Hi");
	
	
	StringBuilder sb1=new StringBuilder("Hi");
	StringBuilder sb2=new StringBuilder("Hi");
	
	
	StringBuffer sb3=new StringBuffer("Hi");
	StringBuffer sb4=new StringBuffer("Hi");
		
	System.out.println("s5 == s6 "+(s5==s6));
	System.out.println("sb1 == sb2 "+(sb1==sb2));
	System.out.println("sb3 == sb4 "+(sb3==sb4));
		
	System.out.println("s5 == s6 "+(s5.equals(s6)));
	System.out.println("sb1 == sb2 "+(sb1.equals(sb2)));
	System.out.println("sb3 == sb4 "+(sb3.equals(sb4)));
	
	
	
}
}
