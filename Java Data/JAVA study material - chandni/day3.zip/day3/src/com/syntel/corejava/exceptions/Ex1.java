package com.syntel.corejava.exceptions;

public class Ex1 {
public static void main(String[] args) {
	
	
try{	
int n=args.length;	
System.out.println("Number of Arguments :"+n);	
System.out.println("Open the files....");
int a=100/n;
System.out.println("a = "+a);
}
catch(Exception e){
//e.printStackTrace();
System.out.println(e);
System.out.println("Please pass the arguments to main method..");
}
finally{
System.out.println("Close the files..");
}
	
}
}
