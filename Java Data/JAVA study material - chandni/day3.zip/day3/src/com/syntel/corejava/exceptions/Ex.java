package com.syntel.corejava.exceptions;

public class Ex {
public static void main(String[] args) {
	
	
int n=args.length;	

System.out.println("Number of Arguments :"+n);	
System.out.println("Open the files....");

String s=null;
s.toLowerCase(); //NullPointerException

int a=100/n;   //ArithmeticException

int arr[]={10};
arr[4]=67;  //ArrayIndexOutOfBoundsException



System.out.println("a = "+a);

System.out.println("Close the files..");

	
}
}
