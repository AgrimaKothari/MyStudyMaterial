package com.syntel.corejava.exceptions;

import java.sql.Date;

public class Ex4 {
	public Ex4() {
	System.out.println("=Ex deflt cons");
	}
	
public static void main(String[] args) {
	
	
	
	try {
		Class c=Class.forName("com.syntel.corejava.exceptions.Ex2");
		System.out.println("Class loaded..");
		Object o=c.newInstance(); //invokes default constructor of loaded class
		
		System.out.println("o ="+o.getClass().getName());
		
		
	} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
	
	
	
	
}
}
