package com.syntel.corejava.exceptions;

import java.util.Scanner;

public class BinaryNumber {
public static void main(String[] args) {
	int a=1000;  //decimal
	int b=03456; //octal
	int c=0x567; //hexa 
	int d=0b1010;//binary     //Java7
	
	System.out.println("a :"+a);
	System.out.println("b :"+b);
	System.out.println("c :"+c);
	System.out.println("d :"+d);
		
	System.out.println("Octal of 1838 :"+Integer.toOctalString(1838));
	System.out.println("Hexa of 1383 :"+Integer.toHexString(1383));
	System.out.println("Binary of 10 :"+Integer.toBinaryString(10));
	
}
}
