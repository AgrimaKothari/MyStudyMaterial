package com.syntel.corejava.basics;

public class StringDemo {
public static void main(String[] args) {
	
	String s=new String("Hello World");
	
	//StringBuffer sb=new StringBuffer("Syntel");
	StringBuilder sb=new StringBuilder("Syntel");
	
	System.out.println("s ="+s);
   String ss =s.toUpperCase();
   
  String sss= ss.concat(ss);
   
	System.out.println("s ="+s+"  ss="+ss+"   sss"+sss);
	
	
	System.out.println("sb ="+sb);
	sb.append(" Pvt Ltd");
	System.out.println("sb ="+sb);
	
	
	
 
	
	
	
	
	
	
}
	
	
}
