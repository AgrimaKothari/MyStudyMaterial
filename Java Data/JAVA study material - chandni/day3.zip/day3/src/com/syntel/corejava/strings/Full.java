package com.syntel.corejava.strings;

import java.util.Scanner;

public class Full {
public static void main(String[] args) {
	
	
	

	StringBuffer s1=new StringBuffer(2);
	
	
	System.out.println("s1 capcity "+s1.capacity());  //2
	
	s1.append("ABC");
	
	
	System.out.println("s1 capcity "+s1.capacity());  //6
	
	s1.append("ABCABCD"); 
	
	System.out.println("s1 capcity "+s1.capacity());  //14
			
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter first name");
	String first=sc.next();
	System.out.println("Enter mid name");
	String mid=sc.next();
	System.out.println("Enter last name");
	String last=sc.next();
	
	
	
	//StringBuffer sb=new StringBuffer(5);
	StringBuilder sb=new StringBuilder();
	
	System.out.println("Capaicty :"+sb.capacity());
	System.out.println("sb :"+sb);
	
	//append first and last name to sb
	sb.append(first);
	System.out.println("Capaicty :"+sb.capacity());
	System.out.println("sb :"+sb);
	
	sb.append(last);
	System.out.println("sb :"+sb);
	System.out.println("After append capacity :"+sb.capacity());
	
	//insert mid name after first name
	int n=first.length();
	sb.insert(n, mid);
	
	System.out.println("After insert capacity :"+sb.capacity());
	
	System.out.println("Full Name :"+sb);
	System.out.println("Reverse Name :"+sb.reverse());
	
	
	
	
	
	
	
	
	
}

}
