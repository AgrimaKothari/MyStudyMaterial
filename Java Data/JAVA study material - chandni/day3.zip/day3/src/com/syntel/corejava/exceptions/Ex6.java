package com.syntel.corejava.exceptions;

import java.util.Scanner;


class InvalidNameException extends Exception{

	public InvalidNameException(String message) {
		super(message);
		
	}

	
	
}




public class Ex6 {
	
	static void printName(String name) throws InvalidNameException{
		System.out.println("In printName");
		
		
		if(!name.matches("[A-z]{3,}"))
		throw new InvalidNameException("Name Should contain only alphabits...");
		
		
		System.out.println("Your Name is :"+name);
	System.out.println("printName over.....");
	}
	
	
	
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);  //Java5
	System.out.println("Enter name :");
	String name=sc.next();
	
	
	
	try {
		System.out.println("Main try");
		printName(name);
		System.out.println("Main try over...");
	} catch (InvalidNameException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	
}
}
