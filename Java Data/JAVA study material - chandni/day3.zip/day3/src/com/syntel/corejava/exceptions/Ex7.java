package com.syntel.corejava.exceptions;

class Employee implements AutoCloseable{
private int id=101;
private String name="Pradeep";


   @Override
	public void close() throws Exception {
	   id=101;
	   name=null;
	System.out.println("Employee close.......");	
	}

}


public class Ex7 {
public static void main(String[] args) {
	
	try(Employee e=new Employee();){
		
		System.out.println("Entering try block");
		System.out.println("Emp "+e);
		System.out.println("Exiting try block");
		}
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
	
}
}
