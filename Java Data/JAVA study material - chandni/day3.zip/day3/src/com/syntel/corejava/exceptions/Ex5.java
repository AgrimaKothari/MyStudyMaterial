package com.syntel.corejava.exceptions;

public class Ex5 {
	
public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
	Class c=Class.forName("com.syntel.corejava.exceptions.Ex2");
	System.out.println("Class loaded...");
	Object object=c.newInstance();
	System.out.println("object :"+object.getClass().getName()); 
	
	
}
}
