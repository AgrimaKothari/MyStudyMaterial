package com.syntel.corejava.exceptions;

import java.util.Scanner;

public class SwithcDemo {
public static void main(String[] args) {
	
	long salary=12_000_00;
	
	
	int a=100; //decimal
	int b=0234;  //octal
	int c=0x456;  //hexa
	
	int d=0b10101; //binary from java7
	
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	
	
	
	
	
	
	
	
	
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter color :");
	String color=sc.next();
	
	switch (color) {
	case "RED":System.out.println("You Entered :"+color);
	break;
	case "GREEN":System.out.println("You Entered :"+color);
	break;
	case "BLUE":System.out.println("You Entered :"+color);
	break;

	default:
		System.out.println("You entered wrong color...");
		break;
	}
	
	
}
}
